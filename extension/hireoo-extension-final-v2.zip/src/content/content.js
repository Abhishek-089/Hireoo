(function(){"use strict";console.log("Hireoo content script loaded on LinkedIn"),chrome.runtime.onMessage.addListener((e,t,n)=>(e.type!=="SCRAPE_VISIBLE_POSTS"&&e.type!=="PERFORM_SCROLL"&&console.log("Content script received message:",e),u(e).then(n).catch(o=>{e.type==="LINKEDIN_PAGE_LOADED"||e.type==="SCRAPE_JOBS"||e.type==="GET_PAGE_INFO"?(console.error("Content script error:",o),n({error:o.message})):n({success:!1,ignored:!0})}),!0));async function u(e,t){switch(e.type){case"LINKEDIN_PAGE_LOADED":return await y(e);case"SCRAPE_JOBS":return await scrapeLinkedInJobs();case"GET_PAGE_INFO":return g();default:return{success:!1,message:`Unknown message type: ${e.type}`}}}async function y(e){return console.log("LinkedIn page loaded:",e.url),e.url.includes("/jobs/")&&(h(),f()),{success:!0,pageType:c(e.url)}}function c(e){return e.includes("/jobs/")?"jobs":e.includes("/feed/")?"feed":e.includes("/in/")?"profile":e.includes("/company/")?"company":"other"}function h(){const e=document.getElementById("hireoo-indicator");e&&e.remove();const t=document.createElement("div");t.id="hireoo-indicator",t.innerHTML=`
    <div style="
      position: fixed;
      top: 20px;
      right: 20px;
      background: #2563eb;
      color: white;
      padding: 8px 12px;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 500;
      z-index: 10000;
      box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
      display: flex;
      align-items: center;
      gap: 6px;
    ">
      <div style="
        width: 6px;
        height: 6px;
        background: #10b981;
        border-radius: 50%;
      "></div>
      Hireoo Active
    </div>
  `,document.body.appendChild(t),setTimeout(()=>{t.style.opacity="0",setTimeout(()=>t.remove(),300)},3e3)}function f(){new MutationObserver(t=>{t.forEach(n=>{n.type==="childList"&&n.addedNodes.forEach(o=>{if(o.nodeType===Node.ELEMENT_NODE){const r=o;(r.matches("[data-job-id]")||r.querySelector("[data-job-id]")||r.matches(".job-card-container")||r.querySelector(".job-card-container"))&&a(r)}})})}).observe(document.body,{childList:!0,subtree:!0}),document.querySelectorAll("[data-job-id], .job-card-container").forEach(t=>{a(t)})}function a(e){if(e.querySelector(".hireoo-job-actions"))return;const t=document.createElement("div");t.className="hireoo-job-actions",t.innerHTML=`
    <button class="hireoo-apply-btn" style="
      background: #2563eb;
      color: white;
      border: none;
      padding: 6px 12px;
      border-radius: 4px;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      margin-top: 8px;
      display: inline-flex;
      align-items: center;
      gap: 4px;
    ">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor">
        <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
      </svg>
      Apply with Hireoo
    </button>
  `;const n=t.querySelector(".hireoo-apply-btn");n.addEventListener("click",async o=>{o.preventDefault(),o.stopPropagation();try{const r=b(e),i=await chrome.runtime.sendMessage({type:"PROCESS_JOB_APPLICATION",jobInfo:r});if(i.success)n.textContent="✓ Applied",n.style.background="#10b981",n.disabled=!0;else throw new Error(i.error)}catch(r){console.error("Failed to apply:",r),n.textContent="❌ Failed",n.style.background="#ef4444"}}),e.appendChild(t)}function b(e){var r,i,d,s,l,p;const t=((r=e.querySelector("[data-job-title]"))==null?void 0:r.textContent)||((i=e.querySelector(".job-card-list__title"))==null?void 0:i.textContent)||"Unknown Title",n=((d=e.querySelector("[data-organization-name]"))==null?void 0:d.textContent)||((s=e.querySelector(".job-card-container__company-name"))==null?void 0:s.textContent)||"Unknown Company",o=((l=e.querySelector("[data-job-location]"))==null?void 0:l.textContent)||((p=e.querySelector(".job-card-container__metadata-item"))==null?void 0:p.textContent)||"Unknown Location";return{title:t==null?void 0:t.trim(),company:n==null?void 0:n.trim(),location:o==null?void 0:o.trim(),linkedinUrl:window.location.href,scrapedAt:new Date().toISOString()}}function g(){return{url:window.location.href,title:document.title,pageType:c(window.location.href),timestamp:Date.now()}}console.log("Hireoo content script initialized")})();
